#include "PumpMotor.h"

PumpMotor::PumpMotor(uint8_t pin, PCF8574 &pcf, uint8_t state)
    : _pin(pin), _pcf(pcf), _state(state) {}

PumpMotor::PumpMotor(uint8_t pin, void (*callback)(uint8_t state),PCF8574 &pcf, uint8_t state)
    : _pin(pin), _callback(callback), _pcf(pcf), _state(state) {}

PumpMotor::~PumpMotor() {};

void PumpMotor::activate() {
    _pcf.write(_pin, HIGH);
    _state = HIGH;

    if (_callback != 0)
        _callback(_state);
}

void PumpMotor::deactivate() {
    _pcf.write(_pin, LOW);
    _state = LOW;

    if (_callback != 0)
        _callback(_state);
}