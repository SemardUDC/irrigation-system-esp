#ifndef PumpMotor_h

#define PumpMotor_h

#include <Arduino.h>
#include "PCF8574.h"

class PumpMotor {
    private:
    uint8_t _pin;
    uint8_t _state;
    PCF8574& _pcf;
    void (*_callback)(uint8_t state);

    public:
    PumpMotor(uint8_t pin, PCF8574 &pcf, uint8_t state = 0);
    PumpMotor(uint8_t pin, void (*callback)(uint8_t state), PCF8574 &pcf, uint8_t state = 0);
    ~PumpMotor();

    void activate();
    void deactivate();

    inline uint8_t getState() { return _state; }
    inline uint8_t getPin() { return _pin; }
};

#endif